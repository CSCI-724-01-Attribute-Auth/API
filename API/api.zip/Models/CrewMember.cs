﻿namespace API.Models
{
    public class CrewMember
    {
        public int MovieId { get; set; }
        public int PersonId { get; set; }
    }
}
